# THW
The Hashnode Writeathon Python Module &amp; API CONNECTOR

This is a simple THW updater that I created for learning purposes during the challenge;

## Usage

Use one of the following APIs to test the different Hashtags

Web 3: 

Web Apps:

Mobile Apps:

Cloud Computing:

## ```code```

``` pip install ```

```
import 

URL = 'https://hashnode.com/api/feed/tag/thw-web3'
web_three = THW(URL).count()

print(web_three)
```

Expected output;

```
......
There are currently 95 posts written!
....

```

The output depends at a time of running this;

Refer to Tests File for more examples;

Read Blog-Series here;

Star this repo if you learnt something from my mini-series
