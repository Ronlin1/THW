from thw import THW

URL = 'https://hashnode.com/api/feed/tag/thw-web3'
web_three = THW(URL).all_posts()

print(web_three)

# Keeping Tabs With The Hashnode Writeathon Challenge
# The Hashnode Epic Writeathon Blog posts and submissions